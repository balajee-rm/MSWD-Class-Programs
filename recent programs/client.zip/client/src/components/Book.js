export default function Book(){
    return(
        <>
            Booking Appoinment Page
        </>
    )
}
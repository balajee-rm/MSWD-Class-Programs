import logo from './logo.svg';
import './App.css';
import axios from 'axios';
import Result from './components/Result';
import { useState } from 'react';

function App() {

  const [result, setResult] = useState(null)

  function handleForm(event) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    var id = data.get("sid");
    var name = data.get("sname");
    console.log(id + " --- " + name);
    axios.post("http://localhost:8082/", {
      sid: id,
      sname: name
    }).then((response)=>{
      console.log(response.data)
      setResult(response.data);
      console.log(result);
    });
  }
  
  if(result == null) {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" style={{width:"70px", height:"70px"}} />
          <p>Website Title Goes Here</p>
        </header>
        <div className="App-body">
          <div className="App-form">
            <form onSubmit={handleForm}>
              Student ID: <input type="text" name="sid" />
              <br/>
              Student Name: <input type="text" name="sname"/>
              <br/>
              <input type="submit" value="save" />
            </form>
          </div>
        </div>
      </div>
    );
  }
  else {
    return(
      <div>
        <Result result={result} />
      </div>
    ); 
  }

}

export default App;

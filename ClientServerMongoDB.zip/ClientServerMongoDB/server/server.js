const { response } = require('express');
const express=require('express');
const {MongoClient} = require('mongodb');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json())

const uri = "mongodb+srv://admin:admin@cluster0.cjqwipx.mongodb.net/?retryWrites=true&w=majority"
const client = new MongoClient(uri);
const db = client.db("smartclass")
const col = db.collection("c525")

app.get('/', (req, res)=> {
    res.send("This is a Server Page");
})

app.post('/', (req, res)=> {
    console.log(req.body);
    col.insertOne(req.body);
    res.send("Successfully Inserted");
})

app.listen(8082);
console.log("Server Started");
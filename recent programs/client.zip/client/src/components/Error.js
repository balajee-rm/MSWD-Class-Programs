export default function Error(){
    return(
        <>
            You are not authorized to this page
        </>
    )
}
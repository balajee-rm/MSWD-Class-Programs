function Result(props) {
    return(
        <div>
            The responce is {props.result}
        </div>
    );
}

export default Result